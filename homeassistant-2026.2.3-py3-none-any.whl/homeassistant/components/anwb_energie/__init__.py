"""Virtual integration: ANWB Energie."""
